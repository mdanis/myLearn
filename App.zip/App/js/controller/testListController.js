app.controller('testListController', function($scope, $http, service,appConst,$window,$location, $routeParams) {

     $scope.siteUrl = siteUrl;
     service.showLoader();
    var callback = function(){
     var parameters = $routeParams; 
     var url = "";
      $http({
         method:"post",
         url:appConst.siteUrl+"/"+appConst.dataUrl+"/json/servicelist/"+$routeParams.containerId+'/'+$routeParams.serviceId,
         headers: {
                    'Content-Type': 'application/json'
                }
     }).success(function(data){
         $scope.testListData = data;
         service.hideLoader();
         $(".custom-scroll-mcq1").mCustomScrollbar({
		theme : "minimal",
		advanced : {
			updateOnContentResize : true
		}
	});
     })
       }
       var newPage = location.hash.split("#/")[1];
        if(newPage){
        var newPageParams = newPage.split("/");
      var paramJson = {
                       "containerId" :newPageParams[1],
                       "serviceId":newPageParams[2],
                       "contentId":newPageParams[3]
                    }
     service.handleFreeService(location.hash.split("#/")[1],paramJson,callback);
    }
    

     
      $scope.showLevel = function(evt,url,params){         
           //service.updateService($scope.siteUrl+url,params); 
            location.hash = "#/testlevel/"+params.containerId+"/"+params.serviceId+"/"+params.type;
       }
       
       $scope.showMCT = function(){
            location.hash = "#/test-multi/"+$routeParams.containerId+'/431';
       }
       $scope.showPractice = function(evt,rackId){
            location.hash = "#/practicepaper/"+rackId+"/"+$scope.testListData.service_id+"/practice";
       }
          
});