app.service('appConst', function() {
  
  return {
    userId : "ankita",
    siteUrl: "",
    startTime:"",
    stopTime:"",
    dataType:"",
    breadscumdata:"",
    containerid:"",
    freeSeviceClassWise: false,
    contentData:"",
    dataUrl:"",
    dataMode:"",
    siteMode:"",
    isUserLogged:"",
    loginStatus:""
  };



});