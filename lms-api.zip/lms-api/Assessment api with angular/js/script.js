// script.js

	// create the module and name it scotchApp
        // also include ngRoute for all our routing needs
	var scotchApp = angular.module('scotchApp', ['ngRoute']);

	// configure our routes
	scotchApp.config(function($routeProvider) {
		$routeProvider

			// route for the home page
			.when('/', {
				templateUrl : 'pages/MCQPuzzel.html',
				controller  : 'assessmentController'
			})

			// route for the about page
			.when('/MCQAssessment', {
				templateUrl : 'pages/MCQAssessment.html',
				controller  : 'MCQAssessment'
			})

			// route for the contact page
			.when('/TFAssessment', {
				templateUrl : 'pages/TFAssessment.html',
				controller  : 'TFAssessment'
			});
	});
	scotchApp.controller('assessmentController', function ($scope) {});
	scotchApp.controller('MCQAssessment', function ($scope) {});
	scotchApp.controller('TFAssessment', function ($scope) {});
	
    