app.controller('emAssessmentController', function($scope, $http, $location, $routeParams) {
    
    $http({
            method: "post",
            url: 'data/emAssessment1.json'
        }).success(function(data) {
            
                acticityArray = data;
                setacticity(acticityArray);
                $('#mcq').addClass('acticityselected');
        });
        $scope.getMcqAssessment = function(evt){
        	 $http({
             method: "post",
             url: 'data/emAssessment2.json'
             }).success(function(data) {
            
                    acticityArray = data;
                    setacticity(acticityArray);
                    $('#tf').removeClass('acticityselected');
                    $(evt.target).addClass('acticityselected');
         });
        }
        
        
        $scope.getTrueFalseAssessment = function(evt){
        	 $http({
             method: "post",
             url: 'data/emAssessment2.json'
             }).success(function(data) {
            
                     acticityArray = data;
                 	 setacticity(acticityArray);
                      $('#mcq').removeClass('acticityselected');
                      $(evt.target).addClass('acticityselected');
         });
        }
})