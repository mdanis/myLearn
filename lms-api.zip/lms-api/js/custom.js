var acticityArray;
$(document).ready(function(){
	                
               /*
                acticityArray ='json1';
                               setacticity();
                               $('#mcq').addClass('acticityselected');
                               
                               
                               $('#mcq').bind('click', function() {
                                   acticityArray ='json1';
                                   setacticity();
                                   $('#tf').removeClass('acticityselected');
                                   $(this).addClass('acticityselected');
                               });
                               
                                $('#tf').bind('click', function() {
                                     acticityArray ='json2';
                                     setacticity();
                                    $('#mcq').removeClass('acticityselected');
                                    $(this).addClass('acticityselected');
                                });*/
               
                 
});
 function setacticity(acticityArray) {
                             $assessmentFactory = new EmAssessmentFactory("");
                             $assessment = $assessmentFactory.createAssessment(
                            "#assessmentMain",
                             acticityArray);
                       }                  