app.config(function($routeProvider,$locationProvider) {
    
            $routeProvider
                   .when('/', {
                            templateUrl : 'templates/emAssessment.html',
                            controller  : 'emAssessmentController'
                    })
	});
        

       

app.run(function($http,$rootScope,$route) {
   
    $rootScope.$on('$locationChangeStart', function($event, newUrl, oldUrl){
    
  });
 
  $rootScope.$on('$routeChangeSuccess', function($event,current) {
  });
  
  
});



	
	
        
      
