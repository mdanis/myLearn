﻿'use strict';

define(['app'], function (app) {

    var injectParams = [];

    var AboutController = function () {

    };

    AboutController.$inject = injectParams;

    app.register.controller('AboutController', AboutController);

});