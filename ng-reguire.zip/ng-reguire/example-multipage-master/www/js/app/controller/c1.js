define(['./Base'], function (Base) {
    var c1 = new Base('Controller 1');
    return c1;
});
