﻿'use strict';
define(['services/routeResolver'], function () {
	var app = angular.module('app', ['ngRoute','routeResolverServices','ui.bootstrap']);         alert(11111111)
	app.config(['$routeProvider', 'routeResolverProvider', '$controllerProvider',
                '$compileProvider',  '$provide', 
        function ($routeProvider, routeResolverProvider, $controllerProvider,$provide) {

            app.register =
            {
                controller: $controllerProvider.register
              //  directive: $compileProvider.directive,
               // filter: $filterProvider.register,
               // factory: $provide.factory,
               // service: $provide.service
            };

            //Define routes - controllers will be loaded dynamically
           var route = routeResolverProvider.route;
          alert(8465464)
            $routeProvider
               
                .when('/a', route.resolve('aController','a'))
                .when('/b', route.resolve('aController','b'))
                .when('/c', route.resolve('aController','c'))

    }]);
    return app;
})

/*
var app = angular.module('app', ['ngRoute']);
app.config(function($routeProvider) {
	$routeProvider
	.when('/', {
		templateUrl : '/view/a.html',
		resolve : resolveController('/js/controller/aController.js'),
		controller : 'a'
	}).when('/b', {
		templateUrl : '/view/b.html',
		resolve : resolveController('/js/controller/bController.js'),
		controller : 'b'
	}).when('/c', {
		templateUrl : '/view/c.html',
		resolve : resolveController('/js/controller/cController.js'),
		controller : 'c'
	});
})
*/

