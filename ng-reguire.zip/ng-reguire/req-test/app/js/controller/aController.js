﻿ define(['app'], function (app) {
 app.register.controller('a',function($scope){
 	alert('a')
 });
 });