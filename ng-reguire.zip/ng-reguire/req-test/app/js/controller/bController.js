﻿ define(['app'], function (app) {
 app.register.controller('b',function($scope){
 	alert('b')
 });
 });