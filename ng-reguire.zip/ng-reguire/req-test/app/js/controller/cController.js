﻿ define(['app'], function (app) {
 app.register.controller('c',function($scope){
 	alert('c')
 });
 });