﻿require.config({
    baseUrl: 'app',
    urlArgs: 'v=1.0'
});

require(
    [
        '../app/app',
        '../app/services/routeResolver',
        '../app/js/controller/aController',
        '../app/js/controller/bController',
        '../app/js/controller/cController'
    ],
    function () {
    	
        //angular.module('app',[]);
        angular.bootstrap(document, ['app']);
    });
   
