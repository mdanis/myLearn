$(document).ready(function(){
	var i=0;
	var iLen = $('.imgContainer').length;
	setInterval(function(){
		if(i > iLen-1){
				var j= iLen-1;
				$('#img'+j+' img:eq(1)').fadeOut('slow')
				$('#img'+j+' img:eq(0)').fadeIn('slow');
				i=0;
			    $('#img'+i+' img:eq(0)').fadeOut('slow')
				$('#img'+i+' img:eq(1)').fadeIn('slow');
		}
		else{
			if(i>0){
				var j= i-1;
				$('#img'+j+' img:eq(1)').fadeOut('slow')
				$('#img'+j+' img:eq(0)').fadeIn('slow');
			}
			$('#img'+i+' img:eq(0)').fadeOut('slow')
		   $('#img'+i+' img:eq(1)').fadeIn('slow');
			
			
			i++;
		}
	},1000);
})
